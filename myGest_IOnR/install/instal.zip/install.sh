#!/bin/bash

echo "installation des elements essentiels du programme"
